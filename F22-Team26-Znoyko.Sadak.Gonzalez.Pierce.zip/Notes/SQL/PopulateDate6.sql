INSERT INTO Customer(Name,Phone_Number,Address)
VALUES
("Andrew Wilkes-Krier","864-254-5861","115 Party Blvd, Anderson SC 29621");
INSERT INTO Customer(Name,Phone_Number,Address)
VALUES
("Matt Engers","864-474-9953",NULL);
INSERT INTO Customer(Name,Phone_Number,Address)
VALUES
("Frank Turner","864-232-8944","6745 Wessex St Anderson SC 29621");
INSERT INTO Customer(Name,Phone_Number,Address)
VALUES
("Milo Auckerman","864-878-5679","879 Suburban Home, Anderson, SC 29621");