INSERT INTO Discount(Name,Percent_Off,Money_Off)
VALUES
("employee",15,NULL);
INSERT INTO Discount(Name,Percent_Off,Money_Off)
VALUES
("Lunch Special Medium",NULL,1);
INSERT INTO Discount(Name,Percent_Off,Money_Off)
VALUES
("Lunch Special Large",NULL,2);
INSERT INTO Discount(Name,Percent_Off,Money_Off)
VALUES
("Specialy Pizza",NULL,1.5);
INSERT INTO Discount(Name,Percent_Off,Money_Off)
VALUES
("Gameday special",20,NULL);