export type AmplifyDependentResourcesAttributes = {
    "api": {
        "SpacebarCowboys": {
            "GraphQLAPIKeyOutput": "string",
            "GraphQLAPIIdOutput": "string",
            "GraphQLAPIEndpointOutput": "string"
        }
    }
}